<?php

$servername = "localhost";
$dBUsername = "succor";
$dbPassword = "}6MByEOhk@5Y";
$dBName = "employees_db";

$conn = mysqli_connect($servername, $dBUsername, $dbPassword, $dBName);

if(!$conn){
	echo "Databese Connection Failed";
}

?>